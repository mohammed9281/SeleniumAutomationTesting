package com.wikiLinks;

import org.json.simple.JSONObject;

import java.util.*;

public class PrintTestResults {

    /**
     * Prints test suite name
     * @throws Exception
     */
    public static void printAllTestSuiteNames() throws Exception {
        String[] suiteNames = JsonReader.getTestSuiteNames();

        //Checking if test suites are available
        if (suiteNames.length != 0) {
            Logger.logOutput("Link Names are");
            for (String suite : suiteNames) {
                Logger.logComment(suite);
            }
        } else {
            Logger.logWarning(String.format("There are no test suite's in json file %s", JsonReader.getTestSuiteFilename()));
        }
    }

    public static void printAllTestDetails(JsonReader.Result result) throws Exception {
        HashMap<String, List<JSONObject>> testResults = JsonReader.getAllTests(result);

        String testName;
        String testExecutionTime;

        //Check if any suite with pass tests available
        if (!testResults.keySet().isEmpty()) {
            Logger.logOutput(String.format("%s List --> Total number of tests that %s and their details", result.toString().toUpperCase(), result.toString()));

            //for each suite
            for (String suite : testResults.keySet()) {
                Logger.logAction("Link Names in Json --> " + suite);

                for (int i = 0; i < testResults.get(suite).size(); i++) {
                    testName = testResults.get(suite).get(i).get("test_name").toString();
                    testExecutionTime = testResults.get(suite).get(i).get("time").toString();
                    Logger.logAction(String.format("%d) %s      -        %s", i+1, testName, testExecutionTime));
                }
            }
            if (result.toString().toLowerCase().contains("blocked")) {
                Logger.logComment("Note - Blocked tests did not execute and hence should not have any duration");
            }
        } else {
            Logger.logWarning(String.format("There are no %s tests in json file %s", result.toString().toUpperCase(), JsonReader.getTestSuiteFilename()));
        }
    }
}
