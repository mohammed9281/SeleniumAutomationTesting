package com.wikiLinks;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

public class WikiPage {
	
	WebDriver driver;
	


	
	
public WikiPage(WebDriver driver) {

	PageFactory.initElements(this.driver, driver);
	this.driver = driver;
}


public void wikiOutput() throws Exception
{
	
	  List<WebElement> alltags = driver.findElements(By.tagName("a"));
	  System.out.println(alltags.size());
	  for(int i=0;i<alltags.size();i++)
	  {
		  System.out.println(alltags.get(i).getAttribute("href"));
		  System.out.println(alltags.get(i).getText());
		 
		  
	  }
	  for(int k=0;k<alltags.size();k++)
	  {
		  String str = alltags.get(k).getAttribute("href");
		  String str2 = alltags.get(k).getText();
		  PrintStream ps = new PrintStream(new File("src\\test\\resources\\TestData\\consoleOutput.txt"));
		  System.setOut(ps);
		  ps.print(str+str2);
		 
	  }
	  
    PrintTestResults test = new PrintTestResults();
    JsonReader.loadTestSuiteFile();

    //Test suite name
    test.printAllTestSuiteNames();

    //Print out the total number of tests that passed and their details
    test.printAllTestDetails(JsonReader.Result.PASS);

    //Print out the total number of tests that failed and their details
    test.printAllTestDetails(JsonReader.Result.FAIL);
}
public static void takeSnapShot(WebDriver webdriver,String path) throws Exception{

    //Convert web driver object to TakeScreenshot

    TakesScreenshot scrShot =((TakesScreenshot)webdriver);

    //Call getScreenshotAs method to create image file

            File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

        //Move image file to new destination

            File DestFile=new File(path);

            //Copy file at destination

            FileUtils.copyFile(SrcFile, DestFile);

}

}
