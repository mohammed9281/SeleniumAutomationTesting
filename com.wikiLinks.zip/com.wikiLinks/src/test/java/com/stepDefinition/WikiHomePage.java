package com.stepDefinition;

import org.testng.annotations.Test;

import com.wikiLinks.JsonReader;
import com.wikiLinks.PrintTestResults;
import com.wikiLinks.WikiPage;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class WikiHomePage {
	WebDriver driver;
	
	 @BeforeMethod
	  public void beforeMethod() {
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  
	  }

  @SuppressWarnings("static-access")
@Test
  public void f() throws Exception {
	  driver.get("https://en.wikipedia.org/wiki/Main_Page");
	  WikiPage pageFile = new WikiPage(driver);
	  pageFile.wikiOutput();
	  pageFile.takeSnapShot(driver, "src\\main\\resources\\com\\wikiLinksScreenShots\\wikipediaHomePage.png");
      }
 	  
  
  @AfterMethod
  public void afterMethod() {
  }

}
